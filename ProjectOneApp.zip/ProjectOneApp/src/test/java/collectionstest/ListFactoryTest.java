package collectionstest;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListFactoryTest {
//
//    @Test
//    public void listFactoryArray() {
//        List<Object> list = CollectionTest.listFactory(1);
//        Assertions.assertTrue(list instanceof ArrayList);
//    }
//
//    @Test
//    public void listFactoryLinked() {
//        List<Object> list = CollectionTest.listFactory(2);
//        Assertions.assertTrue(list instanceof LinkedList);
//    }

}